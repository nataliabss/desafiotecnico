
describe "Acessar site" do 

    it "Acesso ao My Shore e login com sucesso" do 

        visit "http://automationpractice.com/index.php"

        click_link 'Sign in'
        sleep (5)

        find(:xpath, '/html/body/div/div[2]/div/div[3]/div/div/div[2]/form/div/div[1]/input').set 'teste_rj@teste.com'
        sleep (5)

        fill_in 'passwd', with: 'teste123'
        sleep (5)

        click_button 'Sign in'
        sleep (5)

        puts find(:xpath, '/html/body/div/div[2]/div/div[3]/div/p').visible?
        sleep (5)

        find(:xpath, '/html/body/div/div[1]/header/div[3]/div/div/div[6]/ul/li[1]/a').click
        sleep (5)

        
        
        find(:xpath, '/html/body/div/div[2]/div/div[3]/div[2]/ul/li[1]/div/div[1]/div/a[1]/img').click
        sleep (5)

        click_button 'Add to cart'
        sleep (5)

        find(:xpath, '/html/body/div/div[1]/header/div[3]/div/div/div[4]/div[1]/div[2]/div[4]/span').click
        sleep (5)

        find(:xpath, '/html/body/div/div[1]/header/div[3]/div/div/div[6]/ul/li[2]/a').click
        sleep (3)

        find(:xpath, '/html/body/div/div[2]/div/div[3]/div[2]/ul/li[2]/div/div[1]/div/a[1]/img').click
        sleep (3)

        click_button 'Add to cart'
        sleep (5)

        find(:xpath, '/html/body/div/div[1]/header/div[3]/div/div/div[4]/div[1]/div[2]/div[4]/a/span/i').click
        sleep (5)

        find(:xpath, '/html/body/div/div[2]/div/div[3]/div/p[2]/a[1]').click
        sleep (5)

        click_button 'processAddress'
        sleep (3)

        #check 'cgv'
        find(:xpath, '/html/body/div/div[2]/div/div[3]/div/div/form/div/p[2]/div/span').click
        
        sleep (5)

        click_button 'processCarrier'

        sleep (5)

        #click_button 'Pay by bank wire'
        find(:xpath, '/html/body/div/div[2]/div/div[3]/div/div/div[3]/div[1]/div/p/a').click

                
        sleep (5)  

        find(:xpath, '/html/body/div/div[2]/div/div[3]/div/form/p/button').click
        
        sleep (5)

        #'Sign out'
        find(:xpath, '/html/body/div/div[1]/header/div[2]/div/div/nav/div[2]/a').click

        sleep (5)


        




    end

        
            
   
   
        

end
